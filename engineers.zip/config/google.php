<?php 

return [
    // 'client_id' => env('GOOGLE_CLIENT_ID', null),
    // 'client_secret' => env('GOOGLE_CLIENT_SECRET', null),
    // 'redirect_uri' => env('GOOGLE_REDIRECT_URI', null),
    'credentials_path' => base_path('config/apps.googleusercontent.com.json'),
];


?>