<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> تأكيد بريدك الالكتروني </title>
</head>
<body>
    <h1>الرجاء إدخال رمز التحقق لتأكيد حسابك</h1>
    <p>لقد قمت بإنشاء حساب جديد, يرجى إدخال رمز التحقق لتأكيد الحساب</p>
    <h2>{{ $code }}</h2>
    <p>يرجى كتابة رمز التحقق في المنصة</p>
</body>
</html>