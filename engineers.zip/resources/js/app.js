import './bootstrap';
import 'flowbite';
import jQuery from 'jquery';
window.$ = jQuery;

// import $ from 'jquery';
// window.$ = window.jQuery = $;
// window.$ = window.jQuery = require('jquery');
$(document).ready(function(){  
    // alert("Ready!");
});