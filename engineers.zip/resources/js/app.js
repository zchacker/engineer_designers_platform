import './bootstrap';
import $ from 'jquery';
window.$ = window.jQuery = $;

