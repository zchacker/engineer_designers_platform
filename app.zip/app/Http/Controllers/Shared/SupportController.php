<?php

namespace App\Http\Controllers\Shared;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    
    public function list_client(Request $request)
    {
        return view();
    }

    public function list_admin(Request $request)
    {
        return view();
    }

    public function list_supervisor(Request $request)
    {
        return view();
    }

    public function list_engineer(Request $request)
    {
        return view();
    }

    public function create_ticket_engineer(Request $request)
    {

    }

    public function create_ticket_client(Request $request)
    {

    }

    public function create_ticket_action(Request $request)
    {

    }

    public function ticket_details_admin(Request $request)
    {

    }

}
